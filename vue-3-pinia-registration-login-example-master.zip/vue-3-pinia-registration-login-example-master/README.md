# vue-3-pinia-registration-login-example

Vue 3 + Pinia - User Registration and Login Example & Tutorial

Documentation at https://jasonwatmore.com/post/2022/07/25/vue-3-pinia-user-registration-and-login-example-tutorial